-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 15 Haz 2023, 15:54:47
-- Sunucu sürümü: 10.4.28-MariaDB
-- PHP Sürümü: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `library_automation`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kategori`
--

CREATE TABLE `kategori` (
  `Id` int(12) NOT NULL,
  `Kategori_ismi` varchar(255) NOT NULL,
  `Durum` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `kategori`
--

INSERT INTO `kategori` (`Id`, `Kategori_ismi`, `Durum`) VALUES
(2, 'dil kitapları', 'Aktif'),
(5, 'Programlama', 'Aktif'),
(8, 'Proje yönetimi', 'Aktif'),
(9, 'algoritma', 'Aktif'),
(10, 'doğa bilimleri', 'Aktif'),
(11, 'muhasebe', 'Aktif'),
(12, 'finans', 'Aktif'),
(13, 'tarih', 'Aktif'),
(14, 'sosyoloji', 'Aktif'),
(15, 'psikoloji', 'Aktif');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kitaplar`
--

CREATE TABLE `kitaplar` (
  `Id` int(12) NOT NULL,
  `Kitap_ismi` varchar(255) NOT NULL,
  `Kategori` varchar(100) NOT NULL,
  `Yazar_ismi` int(12) NOT NULL,
  `İçerik` text NOT NULL,
  `Sayfa_sayısı` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `kitaplar`
--

INSERT INTO `kitaplar` (`Id`, `Kitap_ismi`, `Kategori`, `Yazar_ismi`, `İçerik`, `Sayfa_sayısı`) VALUES
(1, 'algoritmaların mantığı', '1', 5, 'asdasd', 220),
(2, 'C shell', '4', 5, 'aaaa', 300),
(4, 'ingilizce çalışma kitabı', '2', 5, 'ingilizce', 250),
(5, 'sql öğreniyorum', '5', 6, 'sql', 230),
(6, 'programlama öğreniyorum', '5', 8, 'java', 300),
(7, 'finans öğreniyorum', '12', 9, 'finans giriş', 200),
(8, 'algoritmaların mantığı', '9', 7, 'algoritma', 233);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `lendbook`
--

CREATE TABLE `lendbook` (
  `Id` int(12) NOT NULL,
  `üye_numarasi` int(12) DEFAULT NULL,
  `Kitap_numara` int(12) NOT NULL,
  `Verilis_tarih` date NOT NULL,
  `Getirilis_tarih` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `lendbook`
--

INSERT INTO `lendbook` (`Id`, `üye_numarasi`, `Kitap_numara`, `Verilis_tarih`, `Getirilis_tarih`) VALUES
(6, 5, 1, '2023-06-14', '2023-06-16'),
(7, 3, 2, '2023-06-14', '2023-06-15'),
(12, 8, 5, '2023-06-15', '2023-06-21');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `returnbook`
--

CREATE TABLE `returnbook` (
  `Id` int(12) NOT NULL,
  `üye_no` int(12) NOT NULL,
  `üye_ad` varchar(255) NOT NULL,
  `kitap_ad` varchar(255) NOT NULL,
  `returndate` varchar(255) NOT NULL,
  `elp` int(12) NOT NULL,
  `fine` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `returnbook`
--

INSERT INTO `returnbook` (`Id`, `üye_no`, `üye_ad`, `kitap_ad`, `returndate`, `elp`, `fine`) VALUES
(8, 7, 'aslı ünlü', 'C shell', '2023-06-18', 3, 300);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yazarlar`
--

CREATE TABLE `yazarlar` (
  `Id` int(12) NOT NULL,
  `Yazar_isim` varchar(100) NOT NULL,
  `Adress` text NOT NULL,
  `Telefon` char(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `yazarlar`
--

INSERT INTO `yazarlar` (`Id`, `Yazar_isim`, `Adress`, `Telefon`) VALUES
(5, 'ahmet haşim', '', '5436282992'),
(6, 'selçuk kıran', 'türkiye', '5424355463'),
(7, 'john peter', 'amerika', ''),
(8, 'deniz herand', 'türkiye', '5366477759'),
(9, 'çağla cömert', 'türkiye', '5346221298');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `üyeler`
--

CREATE TABLE `üyeler` (
  `Id` int(12) NOT NULL,
  `Kullanici_isim` varchar(255) DEFAULT NULL,
  `Adress` text NOT NULL,
  `Telefon` char(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `üyeler`
--

INSERT INTO `üyeler` (`Id`, `Kullanici_isim`, `Adress`, `Telefon`) VALUES
(7, 'aslı ünlü', 'türkiye', '5534705756'),
(8, 'yiğit ergün', 'türkiye', '5435304067'),
(9, 'deniz herand', 'türkiye', '5434567789');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `kitaplar`
--
ALTER TABLE `kitaplar`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `lendbook`
--
ALTER TABLE `lendbook`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `returnbook`
--
ALTER TABLE `returnbook`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `yazarlar`
--
ALTER TABLE `yazarlar`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `üyeler`
--
ALTER TABLE `üyeler`
  ADD PRIMARY KEY (`Id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `kategori`
--
ALTER TABLE `kategori`
  MODIFY `Id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Tablo için AUTO_INCREMENT değeri `kitaplar`
--
ALTER TABLE `kitaplar`
  MODIFY `Id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Tablo için AUTO_INCREMENT değeri `lendbook`
--
ALTER TABLE `lendbook`
  MODIFY `Id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Tablo için AUTO_INCREMENT değeri `returnbook`
--
ALTER TABLE `returnbook`
  MODIFY `Id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Tablo için AUTO_INCREMENT değeri `yazarlar`
--
ALTER TABLE `yazarlar`
  MODIFY `Id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Tablo için AUTO_INCREMENT değeri `üyeler`
--
ALTER TABLE `üyeler`
  MODIFY `Id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
